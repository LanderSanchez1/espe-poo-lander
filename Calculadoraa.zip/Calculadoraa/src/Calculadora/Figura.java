package Calculadora;

//Lander Sanchez
	import java.util.Scanner;

	abstract class Figura {
	    public abstract void calcularArea();// Método abstracto para calcular el área de la figura
	    public abstract void calcularPerimetro(); //Método abstracto para calcular el perimetro de la figura
	}

